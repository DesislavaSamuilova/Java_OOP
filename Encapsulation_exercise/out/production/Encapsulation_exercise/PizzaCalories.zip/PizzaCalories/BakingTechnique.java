package PizzaCalories;

public enum BakingTechnique {
        Crispy,
        Chewy,
        Homemade,

    }
