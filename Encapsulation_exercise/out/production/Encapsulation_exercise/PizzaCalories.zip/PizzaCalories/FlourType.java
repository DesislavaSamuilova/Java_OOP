package PizzaCalories;

public enum FlourType {
        White,
        Wholegrain
    }

