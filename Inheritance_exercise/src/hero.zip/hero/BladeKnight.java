package hero;

public class BladeKnight extends DarkKnight{
    private String username;
    private int level;
    public BladeKnight(String name, int level) {
        super(name, level);
    }
}
