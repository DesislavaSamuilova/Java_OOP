package hero;

public class DarkKnight extends Knight{
    private String username;
    private int level;
    public DarkKnight(String name, int level) {
        super(name, level);
    }
}
