package hero;

public class DarkWizard extends Wizard{
    private String username;
    private int level;
    public DarkWizard(String name, int level) {
        super(name, level);
    }
}
