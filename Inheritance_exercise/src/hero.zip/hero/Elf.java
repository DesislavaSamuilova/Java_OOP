package hero;

public class Elf extends Hero{
    private String username;
    private int level;
    public Elf(String name, int level) {
        super(name, level);
    }
}
