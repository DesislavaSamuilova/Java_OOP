package hero;

public class Knight extends Hero{
    private String username;
    private int level;
    public Knight(String name, int level) {
        super(name, level);
    }
}
