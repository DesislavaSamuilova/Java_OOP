package hero;

public class MuseElf extends Elf {
    private String username;
    private int level;

    public MuseElf(String name, int level) {
        super(name, level);
    }
}
