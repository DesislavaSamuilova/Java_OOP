package hero;

public class SoulMaster extends DarkWizard{
    private String username;
    private int level;
    public SoulMaster(String name, int level) {
        super(name, level);
    }
}
