package hero;

public class Wizard extends Hero{
    private String username;
    private int level;
    public Wizard(String name, int level) {
        super(name, level);
    }
}
