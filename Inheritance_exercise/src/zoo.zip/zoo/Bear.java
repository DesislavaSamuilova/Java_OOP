package zoo;

public class Bear extends Mammal {
    private String name;
    public Bear(String name) {
        super(name);
    }
}
