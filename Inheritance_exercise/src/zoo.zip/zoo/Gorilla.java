package zoo;

public class Gorilla extends Mammal{
    private String name;
    public Gorilla(String name) {
        super(name);
    }
}
