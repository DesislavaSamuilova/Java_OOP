package zoo;

public class Lizard extends Reptile{
    private String name;
    public Lizard(String name) {
        super(name);
    }
}
