package zoo;

public class Mammal extends Animal{
    private String name;
    public Mammal(String name) {
        super(name);
    }
}
