package zoo;

public class Reptile extends Animal{
    private String name;
    public Reptile(String name) {
        super(name);
    }
}
