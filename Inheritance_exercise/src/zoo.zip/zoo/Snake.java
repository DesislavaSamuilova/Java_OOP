package zoo;

public class Snake extends Reptile{
    private String name;
    public Snake(String name) {
        super(name);
    }
}
