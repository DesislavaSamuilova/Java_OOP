package spaceStation.models.bags;

import java.util.Collection;

public interface Bag {
    Collection<String> getItems();
}
